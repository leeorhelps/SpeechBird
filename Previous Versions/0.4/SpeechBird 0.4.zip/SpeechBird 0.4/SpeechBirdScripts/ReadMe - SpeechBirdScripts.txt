Normal People
-------------
Q: Scripts? Why?
A: This folder contains scripts that provide *some* of SpeechBird's extra functionality, beyond WSR Macro's native command set's capabilities.

Q: Oh, nice. So, what am I supposed to do about all that?
A: Install the scripts to gain full functionality:
  1) Create a "SpeechBirdScripts" folder if you don't have one yet.
  2) Put all the files in this folder into your "SpeechBirdScripts" folder.
  3) Rename placeholders in the SpeechBird's WSRMac file(s) accordingly. Relevant placeholders are labeled "Placeholder! C:\<Location of Speech Bird scripts folder>\SpeechBirdScripts\". You can do a "search and replace all". Remember to sign your macros afterwards.


Nerds
-----
Q: I'm curious. What does each of these things do?
A:

Temp\
A folder for SpeechBird's temporary stuff
For example, when you dictate text using built in commands that rely on notepad.exe, your text is saved into a file in order to increase reliability and allow you to retrieve previously-dictated texts. If you use a backup with versioning, such as DropBox or Google Drive, I highly recommend adding this folder to that backup to increase reliability by yet another level.
That said, the latest version of SpeechBird uses outlook messages for dictating texts, because: Compatibility with WSR is very high, versions of previously-dictated texts can be saved in the "drafts" folder, undo functionality is better than notepad's, and so are formatting functions such as bold and underline.

cmd.lnk 
This is just a shortcut to C:\Windows\System32\cmd.exe
Primarily used to send text and scribbles to the clipboard, like so:
<run command="Placeholder! C:\<Location of Speech Bird scripts folder>\SpeechBirdScripts\cmd.lnk" params="/c echo | set /p={[scribbles]}|clip" />
Using the .lnk, we can choose to "run minimized", thus reducing distractions.


